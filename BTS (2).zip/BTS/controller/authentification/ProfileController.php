<?php

namespace Controller\Authentification;
use Core\Security\DataSanitize;

use Core\Security\Uploader;
use Exception;
use Model\Authentification\ProfileModel;

class ProfileController
{
    public function show(array $result = [])
    {
        if (!isset($_SESSION['user'])) {
            header('location: ./');
        }

        $user = unserialize($_SESSION['user']);

        $req = req_view(["bloc/Header","bloc/ErrorMessage", "authentification/Profile", "bloc/Footer"]);
        foreach ($req as $req) {
            require $req;
        }
    }
    public function update()
    {
        var_dump($_POST);
        try {
            if (isset($_POST['personnage']) && isset($_POST['datelive']) && $_POST['resume'] !== "") {
                try {

                    $data_sanitizer = new DataSanitize;
                    $model_profile = new ProfileModel;

                    $personnage = $data_sanitizer->sanitize_var($_POST['personnage']);
                    $datelive = $data_sanitizer->sanitize_var($_POST['datelive']);
                    $resume = $_POST["resume"];

                    $model_profile->upload($personnage, $datelive, $resume);
                    

                    $result["error"] = false;
                    $result["message"] = "Le résumé à bien été upload";

                }catch (\Exception $th) {

                    $result['error'] = true;
                    $result['message'] = $th->getMessage();
                }

                $this->show($result);
            }else{
                throw new Exception("Un champs est vide ou mal remplit");
            }
        }catch (\Exception $th) {

            $result['error'] = true;
            $result['message'] = $th->getMessage();
        }
        
    }
}
